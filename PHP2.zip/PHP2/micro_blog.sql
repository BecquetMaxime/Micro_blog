-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 11 avr. 2018 à 14:58
-- Version du serveur :  5.7.19
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `micro_blog`
--

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contenu` text NOT NULL,
  `date` int(11) NOT NULL,
  `vote` int(11) NOT NULL,
  `dislike` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `contenu`, `date`, `vote`, `dislike`) VALUES
(26, 'Message thzrthr', 1515485590, 3, 4),
(48, 'https://www.google.fr/', 1522754283, 3, 0),
(53, 'Message ', 1522758236, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(50) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `sid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `pseudo`, `email`, `password`, `sid`) VALUES
(2, '', 'test@aa.fr', '123', '1510241824'),
(4, '', 'aaa@zzz.fr', '456', '1510241912'),
(6, 'grehrehe', 'admina@rtg.Fr', '75c0d29d069f64f1b94dd34246deac9c', NULL),
(7, 'toto', 'toto@toto.fr', 'f71dbe52628a3f83a77ab494817525c6', NULL),
(8, 'bgngh', 'nbnfn@hnlkgh.fr', 'c4b3d0d188e04b4eed0d639a4e942839', NULL),
(9, 'nngf', 'ngfhn@g.fr', '92eb5ffee6ae2fec3ad71c777531578f', NULL),
(10, 'admin', 'tezt@fa.fr', 'decff46aad9d3ef9ee7464a6f1d94d05', NULL),
(11, 'admineteeeeee', 'ANTOINEfdp@fdp.fr', '0c8591d75c8d1b6ffe0e3cced4ad59ba', NULL),
(12, 'coucou', 'couc@coc.fr', 'f3962c8ae438e070746b2af135edb737', NULL),
(13, 'aret', 'arthur@pd.fr', 'ad1ec92cbb7539feff026b6bfe105c38', NULL),
(14, 'lolo', 'Lolo@lala.fr', '05a9317c7585fa3204f9f88d06bccedd', NULL),
(15, 'azerty', 'azz@zza.fr', '4f7cbff5cefb796ad218f6ed21becdbd', NULL),
(16, 'tatatata', 'taaaaata@tata.fr', '8bbdd71a204c34519980a4bfb43467c3', NULL),
(17, 'aaaaaaazefdzefze', 'l@l.de', '44f2214533a13f31fa9353725eb45aa5', NULL),
(18, 'papapaapa', 'papapapa@pd.fr', '66f2897b1f3f2d5a61d8d9e80348b9d7', NULL),
(19, 'admintest', 'admintest@test.fr', '775b6e55e03e087e7c4502ccf28b6e14', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
