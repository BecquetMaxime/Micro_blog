<?php
include('includes/connexion.inc.php');

$sql="INSERT INTO messages (contenu,date,vote,dislike) VALUES (:contenu, UNIX_TIMESTAMP(),0,0)";
$prep=$pdo->prepare($sql);
$prep->bindvalue(':contenu',$_POST['message']);
$prep->execute();
header("location:index.php");
exit;
?>