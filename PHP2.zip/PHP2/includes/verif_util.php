<?php


//cookie exist ?
// sid ok?
// $connecte=true or false
?>