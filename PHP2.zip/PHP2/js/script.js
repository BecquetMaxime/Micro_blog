$(document).ready(function() {
    function envoibouton(){
        alert('NTM');
    }
        
    
   
});