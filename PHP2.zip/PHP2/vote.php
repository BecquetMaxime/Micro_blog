<?php
include('includes/connexion.inc.php');
if(isset($_GET['t'],$_GET['id']) AND !empty($_GET['t']) AND !empty($_GET['id'])) {
   $getid = (int) $_GET['id'];
   $gett = (int) $_GET['t'];
   
  
      if($gett == 1) {
         
            $ins = $pdo->prepare('UPDATE messages SET vote=vote+1 WHERE id=:id ');
            $ins->bindvalue(':id',$_GET['id']);
            $ins->execute();
            
             header("location:index.php");
          exit;
         }
         
       else if($gett == 2) {
         $ins = $pdo->prepare('UPDATE messages SET dislike=dislike+1 WHERE id=:id ');
            $ins->bindvalue(':id',$_GET['id']);
            $ins->execute();
           
           
             header("location:index.php");
          exit;
         }
      }
      
   

?>